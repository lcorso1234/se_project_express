module.exports = {
  name: "Law",
  about: "A platform to share and discuss legal knowledge.",
  avatar: "https://example.com/avatar.png",
  _id: "64b7f0f2c9e77a001f3d2b5a",
};
